#include <string>
#include <unistd.h>
#include "zoo_service.h"
#include "ini_file.h"
#include "tokenizer.h"

void zookeeper_init_cb(zhandle_t *zh, int type, int state, const char *path, void *context);
void node_create_cb(int rc, const char *value, const void *data);

ZooNode::ZooNode(const char *host, const char *conf_file) {
    _zookeeper_server = host;
    _config_file = conf_file;
    _zoo_handle = NULL;
}

int ZooNode::InitZookeeper() {
    int timeout = read_profile_int("ZOOKEEPER", "timeout", 0, _config_file);

    zoo_set_debug_level(ZOO_LOG_LEVEL_WARN);
    _zoo_handle = zookeeper_init(_zookeeper_server, zookeeper_init_cb, timeout, 0, (void *)_zookeeper_server, 0);
    if (_zoo_handle == NULL) {
        log("zookeeper_init in ZooNode::InitZookeeper failed");
        return -1;
    }

    return 0;
}

void zookeeper_init_cb(zhandle_t *zh, int type, int state, const char *path, void *context) {
    const char *server = (const char *)context;
    if (type == ZOO_SESSION_EVENT) {
        if (state == ZOO_CONNECTED_STATE) {
            log("Connected to zookeeper server %s", server);
        } else if (state == ZOO_EXPIRED_SESSION_STATE) {
            log("Zookeeper session expired on server %s", server);
        } 
    }
}

int ZooNode::Config() {
    char root[MAXLINE] = {0};
    read_profile_string("ZOOKEEPER", "root", root, MAXLINE, "", _config_file);
    string _root(root);
    Tokenizer tokens(_root, ",");
    tokens.Parse();
    vector<string> v_root = tokens.GetTokens();

    char serverlist[MAXLINE] = {0};
    char server[MAXLINE] = {0};
    vector<string> v_server;
    for (int i = 0; i < v_root.size(); ++i) {
        string *temp_root = new string;
        *temp_root = v_root[i];
        int ret = zoo_acreate(_zoo_handle, v_root[i].c_str(), "NULL", 4, &ZOO_OPEN_ACL_UNSAFE, 0, node_create_cb, (void *)temp_root);
        if (ret != ZOK) {
            log("Create root %s failed", v_root[i].c_str());
            return -1;
        }

        memset(serverlist, 0, MAXLINE);
        read_profile_string("ZOOKEEPER", v_root[i].c_str(), serverlist, MAXLINE, "", _config_file);
        string _serverlist(serverlist);
        tokens.Reset(_serverlist, ",");
        tokens.Parse();
        v_server = tokens.GetTokens();

        for (int j = 0; j < v_server.size(); ++j) {
            string *temp_node = new string;
            *temp_node = v_root[i] + "/" + v_server[j];
            int ret = zoo_acreate(_zoo_handle, (*temp_node).c_str(), "NULL", 4, &ZOO_OPEN_ACL_UNSAFE, ZOO_EPHEMERAL, node_create_cb, (void *)temp_node);
            if (ret != ZOK) {
                log("Create temporary node %s failed", v_server[i].c_str());
                return -1;
            }
        }
    }

    return 0;
}

void node_create_cb(int rc, const char *value, const void *data) {
    string *path = (string *)data;

    if (rc == ZOK) {
        log("Create node %s success", (*path).c_str());
    } else if (rc == ZNONODE) {
        log("No parent node for %s", (*path).c_str());
    } else if (rc == ZNODEEXISTS) {
        log("Node %s already exists", (*path).c_str());
    } else if (rc == ZNOCHILDRENFOREPHEMERALS) {
        log("Can't create children for ephemeral node %s", (*path).c_str());
    }

    delete path;
}

int ZooNode::Start() {
    if (InitZookeeper() < 0)
        return -1;

    while (!_zoo_handle) {
        log("Waiting for connecting finished ...");
        sleep(1); //Sleep 1 second to wait for connecting finished
    }

    if (Config() < 0)
        return -1;
}

void ZooNode::Stop() {
    zookeeper_close(_zoo_handle);
}
