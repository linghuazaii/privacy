#include <unistd.h>
#include "zoo_service.h"
#include "ini_file.h"

int main() {
    char host[MAXLINE] = {0};
    read_profile_string("ZOOKEEPER", "server", host, MAXLINE, "", CONFIG_FILE);
    ZooNode zoo_node(host, CONFIG_FILE);
    if (zoo_node.Start() < 0) {
        log("ZooNode start failed");
        exit(1);
    }

    while (1) {
        sleep(86400);
    }

    return 0;
}
