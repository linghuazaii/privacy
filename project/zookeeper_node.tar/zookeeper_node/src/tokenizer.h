#ifndef _TOKENIZER_H
#define _TOKENIZER_H
/*
 *  String tokenize class
 *		2016-6-7 Charles
 */
#include <iostream>
#include <string>
#include <vector>
using std::string;
using std::vector;

class Tokenizer {
public:
	Tokenizer(string str, string delimiter);
	void Parse();
	vector<string> GetTokens();
	unsigned int GetCount();
    void Reset(string str, string delimiter);
private:
	vector<string> _tokens;
	string _text;
	string _delimiter;
	unsigned int _count;
};

#endif
