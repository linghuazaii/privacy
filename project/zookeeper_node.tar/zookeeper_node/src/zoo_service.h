#ifndef _ZOO_SERVICE_H
#define _ZOO_SERVICE_H
/*
 * Zookeeper service for service server to create permanent node
 * and temporary node in Zookeeper.
 * 2016-6-23    Charles
 */

#include "definition.h"
#include "zookeeper/zookeeper.h"
#include "zookeeper/zookeeper_log.h"

class ZooNode {
public:
    ZooNode(const char *host, const char *conf_file);
    int Start();
    void Stop();
    int InitZookeeper();
    int Config();
private:
    const char *_zookeeper_server;
    const char *_config_file;
    zhandle_t *_zoo_handle;
};

#endif
