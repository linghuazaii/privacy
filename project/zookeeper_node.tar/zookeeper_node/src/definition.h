#ifndef _DEFINITION_H
#define _DEFINITION_H
/*
 * Definition of #define(s) and typedef(s)
 * 2016-6-24    Charles
 */

#include <cstring>
#include <time.h>
#include <stdio.h>

#ifdef DEBUG
    #define log(fmt, ...) { \
        time_t now = time(0); \
        char buf[30] = {0}; \
        ctime_r(&now, buf); \
        buf[strlen(buf) - 1] = '\0'; \
        printf("[%s][%s] ", buf, __FUNCTION__); \
        printf(fmt, ##__VA_ARGS__); } \
        printf("\n")
#else
    #define log(fmt, ...)
#endif

#define CONFIG_FILE "../conf/zookeeper.ini"

#define MAXLINE 256

#endif
