#include <iostream>
#include <string>
#include <vector>
#include "tokenizer.h"
using namespace std;

Tokenizer::Tokenizer(string str, string delimiter) {
	_text = str;
	_delimiter = delimiter;
	_count = 0;
}

void Tokenizer::Parse() {
	int start = 0, pos;
	do {
		pos = _text.find(_delimiter, start);
		if (pos != string::npos) {
			string temp = _text.substr(start, pos - start);
			_tokens.push_back(temp);
			++_count;
			start = pos + 1;
		} else {
			string temp = _text.substr(start);
			_tokens.push_back(temp);
			++_count;
			break;
		}
	} while (1);
}

vector<string> Tokenizer::GetTokens() {
	return _tokens;
}

unsigned int Tokenizer::GetCount() {
	return _count;
}

void Tokenizer::Reset(string str, string delimiter) {
    _tokens.clear();
    _count = 0;
    _text = str;
    _delimiter = delimiter;
}
